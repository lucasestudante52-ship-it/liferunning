let map, polyline, watchId;
let distance = 0;
let lastPosition = null;

// Inicia o mapa
function initMap() {
    map = L.map('map').setView([0, 0], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19
    }).addTo(map);

    polyline = L.polyline([], { color: 'red', weight: 5 }).addTo(map);
}

// Calcula distância entre 2 pontos (Haversine)
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // metros
    const toRad = x => (x * Math.PI) / 180;
    const φ1 = toRad(lat1);
    const φ2 = toRad(lat2);
    const Δφ = toRad(lat2 - lat1);
    const Δλ = toRad(lon2 - lon1);

    const a = Math.sin(Δφ/2) ** 2 +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // metros
}

// Atualiza HUD
function updateStats() {
    document.getElementById('distance').textContent = `${distance.toFixed(1)} m`;
    document.getElementById('points').textContent = Math.floor(distance);
}

// Inicia rastreamento
function startTracking() {
    if (navigator.geolocation) {
        watchId = navigator.geolocation.watchPosition(pos => {
            const { latitude, longitude } = pos.coords;

            if (!lastPosition) {
                lastPosition = { lat: latitude, lon: longitude };
                map.setView([latitude, longitude], 18);
            } else {
                const dist = calculateDistance(lastPosition.lat, lastPosition.lon, latitude, longitude);
                if (dist > 0.5) { // ignora pequenas variações
                    distance += dist;
                    lastPosition = { lat: latitude, lon: longitude };
                    polyline.addLatLng([latitude, longitude]);
                    updateStats();
                }
            }
        }, err => alert('Erro no GPS: ' + err.message), { enableHighAccuracy: true });
    } else {
        alert("GPS não suportado neste dispositivo.");
    }
}

// Para rastreamento
function stopTracking() {
    if (watchId) {
        navigator.geolocation.clearWatch(watchId);
        watchId = null;
    }
}

// Ranking
function loadRanking() {
    const ranking = JSON.parse(localStorage.getItem('ranking')) || [];
    ranking.sort((a, b) => b.points - a.points);

    const list = document.getElementById('ranking');
    list.innerHTML = '';
    ranking.forEach(player => {
        const li = document.createElement('li');
        li.textContent = `${player.name} — ${player.points} pts`;
        list.appendChild(li);
    });
}

function saveScore() {
    const name = document.getElementById('playerName').value.trim();
    if (!name) return alert("Digite seu nome!");

    const ranking = JSON.parse(localStorage.getItem('ranking')) || [];
    ranking.push({ name, points: Math.floor(distance) });
    localStorage.setItem('ranking', JSON.stringify(ranking));
    loadRanking();
}

// Eventos
document.getElementById('startBtn').addEventListener('click', startTracking);
document.getElementById('stopBtn').addEventListener('click', stopTracking);
document.getElementById('saveScoreBtn').addEventListener('click', saveScore);

initMap();
loadRanking();
