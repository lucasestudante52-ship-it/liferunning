LifeRunning - Projeto
---------------------
Como usar:
1. Abra o arquivo index.html em um navegador (recomendado: Chrome ou Safari em mobile).
2. Permita acesso à localização quando solicitado.
3. Clique em "Iniciar" para começar o rastreamento.
4. Clique em "Parar" para interromper.
5. Digite seu nome e clique em "Salvar Pontuação" para adicionar ao ranking (armazenado no LocalStorage).

Observações:
- O mapa usa Leaflet com tiles do OpenStreetMap.
- Para testar em desktop, você pode simular geolocalização (ferramentas de desenvolvedor).
